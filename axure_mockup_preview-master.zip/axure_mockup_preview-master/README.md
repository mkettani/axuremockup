# axure_mockup_preview
Game/Software shop website mockup, demonstrating basic abilities with Axure RP 8
